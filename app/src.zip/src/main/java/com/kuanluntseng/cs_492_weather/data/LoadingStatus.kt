package com.kuanluntseng.cs_492_weather.data

enum class LoadingStatus {
    LOADING,
    ERROR,
    SUCCESS
}