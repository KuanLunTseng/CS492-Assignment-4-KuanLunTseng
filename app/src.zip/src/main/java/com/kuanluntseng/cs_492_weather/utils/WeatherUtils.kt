package com.kuanluntseng.cs_492_weather.utils

class WeatherUtils {
    fun buildWeatherQueryTerm(query: String) : String {
        var queryTerm = query
        return queryTerm
    }
}